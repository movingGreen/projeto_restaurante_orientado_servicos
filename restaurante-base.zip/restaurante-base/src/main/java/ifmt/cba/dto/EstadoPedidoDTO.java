package ifmt.cba.dto;

public enum EstadoPedidoDTO {
    
    REGISTRADO,
    PRODUCAO,
    PRONTO,
    ENTREGA,
    CONCLUIDO
}
