package ifmt.cba.dto;

public enum EstadoOrdemProducaoDTO {
    
    REGISTRADA,
    PROCESSADA
}
